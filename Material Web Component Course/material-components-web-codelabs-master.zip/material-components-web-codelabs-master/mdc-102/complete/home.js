import {MDCList} from '@material/list';

new MDCList(document.querySelector('.mdc-list'));
